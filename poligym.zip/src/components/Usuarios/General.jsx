import React from 'react'

export const General = () => {
    return (
        <div>General</div>
    )
}
