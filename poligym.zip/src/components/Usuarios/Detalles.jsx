import React from 'react'

export const Detalles = () => {
    return (
        <div>Detalles</div>
    )
}
