import React from 'react'

export const Ejercicios = () => {
    return (
        <div className='bg-white rounded-lg pb-4 shadow h-full p-4'>
            <h1 className='montserrat-alternates text-azul-marino-500 text-3xl font-semibold'>Ejercicios</h1>

        </div>
    )
}
