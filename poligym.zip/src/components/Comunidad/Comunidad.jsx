import React from 'react'

export const Comunidad = () => {
    return (
        <div className='bg-white rounded-lg pb-4 shadow h-full p-4'>
            <h1 className='montserrat-alternates text-azul-marino-500 text-3xl font-semibold'>Comunidad</h1>

        </div>
    )
}
